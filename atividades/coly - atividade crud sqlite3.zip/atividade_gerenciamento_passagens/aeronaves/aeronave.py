class Aeronave:
    def __init__(self, cod_aeronave, cod_linha_aerea, modelo, capacidade_passageiros, ano):
        self.cod_aeronave = cod_aeronave
        self.cod_linha_aerea = cod_linha_aerea
        self.modelo = modelo
        self.capacidade_passageiros = capacidade_passageiros
        self.ano = ano