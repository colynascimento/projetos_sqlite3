class AjustePreco:
    def __init__(self, cod_ajuste, cod_voo, tipo_ajuste, valor_porcentual, descricao, data_inicio, data_fim):
        self.cod_ajuste = cod_ajuste
        self.cod_voo = cod_voo
        self.tipo_ajuste = tipo_ajuste
        self.valor_porcentual = valor_porcentual
        self.descricao = descricao
        self.data_inicio = data_inicio
        self.data_fim = data_fim