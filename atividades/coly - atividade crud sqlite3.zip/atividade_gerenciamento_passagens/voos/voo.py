class Voo:
    def __init__(self, cod_voo, cod_rota, cod_linha_aerea, cod_aeronave, cod_iata_origem, cod_iata_destino, data_hora_partida, data_hora_chegada, plataforma):
        self.cod_voo = cod_voo
        self.cod_rota = cod_rota
        self.cod_linha_aerea = cod_linha_aerea
        self.cod_aeronave = cod_aeronave
        self.cod_iata_origem = cod_iata_origem
        self.cod_iata_destino = cod_iata_destino
        self.data_hora_partida = data_hora_partida
        self.data_hora_chegada = data_hora_chegada
        self.plataforma = plataforma