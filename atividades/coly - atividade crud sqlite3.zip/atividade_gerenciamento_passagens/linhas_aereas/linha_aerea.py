class LinhaAerea:
    def __init__(self, cod_linha_aerea, nome, pais_origem, contato_suporte, email):
        self.cod_linha_aerea = cod_linha_aerea
        self.nome = nome
        self.pais_origem = pais_origem
        self.contato_suporte = contato_suporte
        self.email = email